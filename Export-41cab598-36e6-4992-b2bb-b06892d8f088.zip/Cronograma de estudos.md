# Cronograma de estudos

## 📅 Cronograma semanal

[Meu cronograma semanal](Cronograma%20de%20estudos/Meu%20cronograma%20semanal.csv)

## 📅 Cronograma diário

[Calendário de estudos](Cronograma%20de%20estudos/Calend%20rio%20de%20estudos.csv)