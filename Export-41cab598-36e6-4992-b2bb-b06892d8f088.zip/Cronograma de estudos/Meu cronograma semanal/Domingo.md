# Domingo

Hora de início: 13:00
Hora de término: 17:00