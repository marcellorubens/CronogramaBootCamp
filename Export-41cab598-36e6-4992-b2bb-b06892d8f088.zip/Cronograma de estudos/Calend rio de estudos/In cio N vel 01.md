# Início Nível 01

Data: Apr 06, 2020
Hora de início: 21:00
Hora de término: 11:00
Status: Iniciado

Hoje irei iniciar o Nível 01 do bootcamp.