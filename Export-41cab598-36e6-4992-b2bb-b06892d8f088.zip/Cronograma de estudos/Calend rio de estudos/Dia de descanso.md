# Dia de descanso

Data: Mar 29, 2020

Hoje é o dia que irei tirar para descanso e/ou me alinhar com minhas outras necessidades.

Aqui posso definir tarefas que preciso realizar que irão me ajudar na faculdade, trabalho, etc.

### Terei tempo disponível?

- [ ]  Ouvir algum episódio do Podcast FALADEV que eu tiver interesse