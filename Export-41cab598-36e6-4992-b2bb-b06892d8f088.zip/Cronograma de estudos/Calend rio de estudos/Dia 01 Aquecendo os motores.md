# Dia 01 - Aquecendo os motores

Data: Mar 30, 2020
Hora de início: 19:00
Hora de término: 22:00
Status: Finalizado

Hoje eu vou começar definindo o que eu vou fazer durante a semana. 

Isso vai me ajudar a ter compromisso com meus estudos, e ajudar planejar o que eu vou estudar para chegar ao meu próximo nível 🚀

- [x]  Definir o meu tempo disponível para estudos por dia
- [x]  Definir em qual horário em irei estudar
- [x]  Criar um "banco de dados" de aulas para me ajudar a planejar o que eu devo estudar
- [x]  Criar uma tarefas definindo o que eu devo fazer em cada dia