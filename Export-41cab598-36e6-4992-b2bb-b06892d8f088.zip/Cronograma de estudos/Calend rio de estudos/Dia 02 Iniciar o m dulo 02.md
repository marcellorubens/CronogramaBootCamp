# Dia 02 - Iniciar o módulo 02

Data: Mar 31, 2020
Hora de início: 19:00
Hora de término: 22:00
Status: Finalizado

Aqui eu irei iniciar a assistir o módulo 02, onde irei configurar o meu ambiente de desenvolvimento para aumentar minha produtividade enquanto eu estiver codando.

Hoje será um dia que eu irei focar totalmente no primeiro módulo, para ter todo meu ambiente preparado para os próximos dias. 

Caso eu não consiga assistir tudo hoje, assistirei o restante das aulas amanhã.

### Bootcamp GoStack

- [ ]  Assistir a aula `01 - Instalando o node` (19:00 - 19:05)
- [ ]  Assistir a aula `02 - Instalando o yarn` (19:05 - 19:10)
- [ ]  Assistir a aula `03 - Visual studio code` (19:10 - 19:15)
- [ ]  Assistir a aula `04 - Configurações do editor` (19:15 - 19:30)
- [ ]  Pausa para descansar (19:30 - 19:35)
- [ ]  Assistir a aula `05 - Terminal Oh My Zsh` (19:35 - 19:40)
- [ ]  Assistir a aula `06 - Instalando git e github` (19:45 - 19:50)
- [ ]  Assistir a aula `07 - Configurações git` (19:50 - 19:55)
- [ ]  Assistir a aula `08 - JSON Viewer` (19:55 - 20:00)
- [ ]  Assistir a aula `09 - React Devtools` (20:00 - 20:05)
- [ ]  Assistir a aula `10 - Octotree` (20:05 - 20:10)
- [ ]  Pausa para descansar (20:10 - 20:15)
- [ ]  Assistir a aula `11 - Notion` (20:15 - 20:20)
- [ ]  Assistir a aula `12 - Whimsical` (20:20 - 20:25)
- [ ]  Assistir a aula `13 - DevDocs` (20:25 - 20:30)
- [ ]  Assistir a aula `14 - Whimsical` (20:20 - 20:25)
- [ ]  Assistir a aula `15 - Insomnia` (20:25 - 20:30)
- [ ]  Pausa para descansar (20:30 - 20:35)