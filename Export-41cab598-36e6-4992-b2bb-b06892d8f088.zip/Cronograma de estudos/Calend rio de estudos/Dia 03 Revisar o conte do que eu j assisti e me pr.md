# Dia 03 - Revisar o conteúdo que eu já assisti e me preparar para a próxima semana

Data: Apr 01, 2020
Hora de início: 19:00
Hora de término: 22:00
Status: Finalizado

Hoje eu vou tentar continuar no ritmo de estudos!

- [ ]  Revisar o cronograma de aulas, para tentar me preparar para a próxima semana.

### Ainda não me sinto confortável com JavaScript?

- [ ]  Assistir o curso `Javascript` do [STARTER](https://rocketseat.com.br/starter) da rocketseat

### Já me sinto seguro e quero iniciar na prática?

- [ ]  Assistir a aula `Como Publicar Pacotes no NPM | Code/Drops #24` no canal do youtube da Rocketseat

### Conteúdo extra

- [ ]  Ouvir o podcast `Técnicas de estudo e aprendizado tradicional | Podcast FalaDev #11` no canal da Rocketseat do youtube (20:35 - 21:18)