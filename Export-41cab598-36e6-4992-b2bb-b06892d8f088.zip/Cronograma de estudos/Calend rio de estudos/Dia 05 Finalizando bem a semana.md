# Dia 05 - Finalizando bem a semana

Data: Apr 03, 2020
Status: Finalizado

Hoje será o dia que eu irei botar o que eu aprendi até agora em prática!

### Produção de conteúdo

- [x]  Produza um texto falando sobre o que você aprendeu até aqui, o que você não sabia e que agora sabe, e como está sendo se desafiar nesse processo.
- [ ]  Fazer um post no Linkedin com o texto que eu acabei de escrever, para mostrar os meus esforços para alcançar o próximo nível.

### Conteúdo extra

- [ ]  Ouvir algum episódio do Podcast FALADEV que eu tiver interesse